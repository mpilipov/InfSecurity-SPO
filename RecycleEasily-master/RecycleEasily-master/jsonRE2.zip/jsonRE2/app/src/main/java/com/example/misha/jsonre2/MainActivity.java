package com.example.misha.jsonre2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
//import com.google.common.base.Strings;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;


public class MainActivity extends AppCompatActivity {
    //String json_string =
    Button btnjson;
    TextView tvData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvData = (TextView) findViewById(R.id.textView);
        btnjson = (Button) findViewById(R.id.buttonjson);
        btnjson.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                gettingJSON();

            }
        });
    }
    void gettingJSON()
    {
        try{
            String x = "";
            InputStream is = this.getResources().openRawResource(R.raw.out);
            byte [] buffer = new byte[is.available()];
            while (is.read(buffer)!=-1);
            String jsoncontext = new String(buffer);
            JSONArray entires = new JSONArray(jsoncontext);

            for (int i = 0; i<entires.length();i++)
            {
                JSONObject post = entires.getJSONObject(i);
                x += "\nНомер станции: " + post.getString("pk")+"\n";
                x += "Название: " + post.getJSONObject("fields").getString("name")+"\n";
                if (!(post.getJSONObject("fields").getString("telephone").isEmpty() ) ) {
                    x += "Телефон: " + post.getJSONObject("fields").getString("telephone") + "\n";
                }
                if (!(post.getJSONObject("fields").getString("description").isEmpty() ) ) {
                    x += "Сайт: " + post.getJSONObject("fields").getString("description")+"\n";
                }

                x += "Адрес: " + post.getJSONObject("fields").getString("address")+"\n";
                if (!(post.getJSONObject("fields").getJSONObject("schedule").optString("Пн - Сб").isEmpty() ) ){
                    x += "Часы работы: " + post.getJSONObject("fields").getJSONObject("schedule").getString("Пн - Сб")+"\n";
                }
                if (!(post.getJSONObject("fields").getJSONObject("schedule").optString("Пн - Пт").isEmpty() ) ){
                    x += "Часы работы: " + post.getJSONObject("fields").getJSONObject("schedule").getString("Пн - Пт")+"\n";
                }
                if (!(post.getJSONObject("fields").getJSONObject("schedule").optString("Сб - Вс").isEmpty() ) ){
                    x += "Часы работы: " + post.getJSONObject("fields").getJSONObject("schedule").getString("Сб - Вс")+"\n";
                }
                if (!(post.getJSONObject("fields").getJSONObject("schedule").optString("Пн - Вс").isEmpty() ) ){
                    x += "Часы работы: " + post.getJSONObject("fields").getJSONObject("schedule").getString("Пн - Вс")+"\n";
                }
                x += "Типы принимаемых отходов: \n";
                if ((post.getJSONObject("fields").getJSONObject("trash").optString("Батарея").isEmpty() ) && (!(post.getJSONObject("fields").getJSONObject("trash").isNull("Батарея")))) {
                    x += "Батарея ";
                }
                if ((post.getJSONObject("fields").getJSONObject("trash").optString("Пластик").isEmpty() ) && (!(post.getJSONObject("fields").getJSONObject("trash").isNull("Пластик")))) {

                    x += "Пластик";
                }
                if ((post.getJSONObject("fields").getJSONObject("trash").optString("Макулатура").isEmpty() ) && (!(post.getJSONObject("fields").getJSONObject("trash").isNull("Макулатура")))) {
                    x += ", Макулатура";
                }
                if ((post.getJSONObject("fields").getJSONObject("trash").optString("Стекло").isEmpty() ) && (!(post.getJSONObject("fields").getJSONObject("trash").isNull("Стекло")))) {
                    x += ", Стекло";
                }
                if ((post.getJSONObject("fields").getJSONObject("trash").optString("Металл").isEmpty() ) && (!(post.getJSONObject("fields").getJSONObject("trash").isNull("Металл")))) {
                    x += ", Металл";
                }

                x+="\n";
                if (!(post.getJSONObject("fields").getJSONObject("trash").optString("Опасные").isEmpty() ) ) {
                    x += "Опасные отходы: "+post.getJSONObject("fields").getJSONObject("trash").optString("Опасные")+"\n";
                }
                    x+= "\n";

               // x += "Телефон" + post.getString("telephone")+",\n";
              //  x += "Сайт" + post.getString("description")+"\n";
              //  x += "Адрес" + post.getString("adress");
                //x += "Расписание" + post.getString("schedule");


            }
            tvData.setText(x);

        }
        catch (Exception je)
        {
            tvData.setText("error" + je.getMessage());
        }
    }
}


