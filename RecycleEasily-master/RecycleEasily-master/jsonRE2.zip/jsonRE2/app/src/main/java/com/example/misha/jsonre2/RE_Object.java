package com.example.misha.jsonre2;

/**
 * Created by misha on 25.11.2016.
 */
public class RE_Object {
    int pk;
    String name;
    String telephone;
    int pos_x;
    int pos_y;
    String description;
    String adress;
    String schedule;
    String trash;

}
